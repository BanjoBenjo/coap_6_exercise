/*
 * main.h
 *
 *  Created on: 17.06.2020
 *      Author: Tomas Schweizer
 */

#ifndef MAIN_H_
#define MAIN_H_

//*****************************************************************************
//
// Defines for setting up the system clock.
//
//*****************************************************************************
#define SYSTICKHZ               100
#define SYSTICKMS               (1000 / SYSTICKHZ)


//*****************************************************************************
//
// Timeout for DHCP address request (in seconds)
//
//*****************************************************************************
#ifndef DHCP_EXPIRE_TIMER_SECS
#define DHCP_EXPIRE_TIMER_SECS  45
#endif

//*****************************************************************************
//
// IP address values for the lwiplib
//
//*****************************************************************************

#define IP_LINK_DOWN (0xffffffffU)              // No Link
#define IP_LINK_UP (0)                          // DHCP Process



#endif /* MAIN_H_ */
