/*
 * uartConfig.c
 *
 *  Created on: 13.06.2020
 *      Author: Tomas Schweizer
 */

#include <stdint.h>
#include <stdbool.h>

#include "inc/hw_memmap.h"          // for several predefined macros like "GPIO_PORTN_BASE"
#include "inc/hw_ints.h"            // Macros that define the interrupt assignment on Tiva C Series MCUs (e.g. "INT_TIMER0A")
#include "driverlib/sysctl.h"       // clock
#include <driverlib/uart.h>
#include "utils/uartstdio.h"
#include "utils/ustdlib.h"


#include "uartConfig.h"

// The system clock speed.
extern uint32_t g_ui32SysClock;

void uartConfig_init(){


    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);                // Enable UART0

    // Configure debug port for internal use. (UARTStdioConfig(uint32_t ui32PortNum, uint32_t ui32Baud, uint32_t ui32SrcClock))
    UARTStdioConfig(0, 115200, g_ui32SysClock);

    // Clear the terminal and print a banner.
    UARTprintf("\033[2J\033[H");
    UARTprintf("VS CoAP Client ");
    UARTprintf("1");
    UARTprintf("\n\n");

    return;
}
