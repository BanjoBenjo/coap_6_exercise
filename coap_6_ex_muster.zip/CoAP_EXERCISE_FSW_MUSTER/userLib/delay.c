#include <stdint.h>
#include <stdbool.h>

#include "inc/hw_memmap.h"          // for several predefined macros like "GPIO_PORTN_BASE"
#include "inc/hw_ints.h"            // Macros that define the interrupt assignment on Tiva C Series MCUs (e.g. "INT_TIMER0A")
#include "driverlib/sysctl.h"

/*
 * delay.c
 *
 *  Created on: 11.05.2020
 *      Author: Leon Fixl
 */

// Delay for n milliseconds
void delay_ms(int n)
{
    SysCtlDelay(n*(120000000/(3*1000)));
}


