/*
 * uartConfig.h
 *
 *  Created on: 13.06.2020
 *      Author: Tomas Schweizer
 */

#ifndef USERLIB_UARTCONFIG_H_
#define USERLIB_UARTCONFIG_H_

    /** @uart configuration
     *
     *
     */

    void uartConfig_init();


#endif /* USERLIB_UARTCONFIG_H_ */
