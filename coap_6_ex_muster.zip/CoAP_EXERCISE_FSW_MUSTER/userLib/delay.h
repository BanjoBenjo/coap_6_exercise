/*
 * delay.h
 *
 *  Created on: 11.05.2020
 *      Author: Leon Fixl
 */

#ifndef DELAY_H_
#define DELAY_H_


    void delay(int n);


#endif /* DELAY_H_ */



