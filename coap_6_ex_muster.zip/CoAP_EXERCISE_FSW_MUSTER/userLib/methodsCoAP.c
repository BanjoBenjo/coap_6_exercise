/*
 * methodsCoap.c
 *
 *  Created on: 25.06.2020
 *      Author: Tomas Schweizer
 *              Leon Fixl
 *              Benjamin Wagner
 */

// standart includes
#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

// Mongoose library
#include "mongoose/mongoose.h"
#include "../utils/uartstdio.h"

#include "methodsCoAP.h"

//*****************************************************************************
//
// Generate message ID for CoAP messages
//
//*****************************************************************************
uint16_t generateMessageID(uint16_t l_ui16MessageID){

    // randomize first message ID for security reasons
    if(l_ui16MessageID == NULL){

        srand(time(NULL));

        // random int betweeen 0 and 1000
        l_ui16MessageID = rand() % 1000;

    } else if (l_ui16MessageID >= 65536){

        l_ui16MessageID = 0;
    }
    else {

        l_ui16MessageID++;
    }

   return l_ui16MessageID;

}


//*****************************************************************************
//
// DISCOVERY method CoAP (based on GET method)
//
//*****************************************************************************
uint16_t DISCOVERY_Met(struct mg_connection *nc, struct mg_mgr mgr, uint16_t l_ui16MessageID){

    // Variables for coap message
    struct mg_coap_message cm;
    uint32_t res;

    // Initialization of a CON, GET-A, Uri-path[basic]
    memset(&cm, 0, sizeof(cm));

    // set message ID for message
    cm.msg_id = generateMessageID(l_ui16MessageID);

    cm.msg_type = MG_COAP_MSG_CON;
    cm.code_detail = MG_COAP_MSG_GET;
    cm.code_class = MG_COAP_CODECLASS_REQUEST;
    cm.token.len = sizeof(char);
    cm.token.p = "5";

    // GET Uri Path for Discovery ".well-known/core => (-1 cause EOS)
    mg_coap_add_option(&cm, 11, COAP_URI_PATH_DISCOVERY, sizeof(COAP_URI_PATH_DISCOVERY) - 1);

    mg_coap_add_option(&cm, 12, COAP_CONTENT_FORMAT_LINK_FORMAT, sizeof(COAP_CONTENT_FORMAT_LINK_FORMAT) - 1);

    res = mg_coap_send_message(nc, &cm);

    mg_coap_free_options(&cm);

    // error check
    if (res == 0) {
      UARTprintf("Sent CON with msg_id = %d\n", cm.msg_id);

    } else {

       UARTprintf("Error: %d\n", res);
    }

    return cm.msg_id;
}

//*****************************************************************************
//
// PUT method CoAP
//
//*****************************************************************************
uint16_t PUT_Met(struct mg_connection *nc, struct mg_mgr mgr, uint16_t l_ui16MessageID, char payload[])
{

    // Variables for coap message
    struct mg_coap_message cm;
    uint32_t res;

    // Initialization of a CON, GET-A, Uri-path[basic]
    memset(&cm, 0, sizeof(cm));
    cm.msg_id = generateMessageID(l_ui16MessageID);
    cm.msg_type = MG_COAP_MSG_CON;
    cm.code_detail = MG_COAP_MSG_PUT;
    cm.token.len = sizeof(char);
    cm.token.p = "2";

    cm.payload.p = payload;
    cm.payload.len = strlen(payload);

    mg_coap_add_option(&cm, 11, COAP_URI_PATH_BASIC, (strlen(COAP_URI_PATH_BASIC)));

    mg_coap_add_option(&cm, 12, COAP_CONTENT_FORMAT_PLAIN_TEXT, sizeof(COAP_CONTENT_FORMAT_PLAIN_TEXT) - 1);

    res=mg_coap_send_message(nc, &cm);

    mg_coap_free_options(&cm);


    // error check
    if (res == 0)
    {
       UARTprintf("Sent CON with msg_id = %d\n", cm.msg_id);
    }
    else
    {
        UARTprintf("Error: %d\n", res);
    }

    return cm.msg_id;
}

//*****************************************************************************
//
// GET method CoAP
//
//*****************************************************************************
uint16_t GET_Met(struct mg_connection *nc,struct mg_mgr mgr, uint16_t l_ui16MessageID){

// Variables for coap message
    struct mg_coap_message cm;
    uint32_t res;

    // Initialization of a CON, GET-A, Uri-path[basic]
    memset(&cm, 0, sizeof(cm));

    // set message ID for message
    cm.msg_id = generateMessageID(l_ui16MessageID);

    cm.msg_type = MG_COAP_MSG_CON;
    cm.code_detail = MG_COAP_MSG_GET;
    cm.code_class = MG_COAP_CODECLASS_REQUEST;
    cm.token.len = sizeof(char);
    cm.token.p = "1";

    // GET Uri Path => (-1 wegen /n im string)
    mg_coap_add_option(&cm, 11, COAP_URI_PATH_BASIC, strlen(COAP_URI_PATH_BASIC));

    mg_coap_add_option(&cm, 12, COAP_CONTENT_FORMAT_PLAIN_TEXT, sizeof(COAP_CONTENT_FORMAT_PLAIN_TEXT) - 1);

    res=mg_coap_send_message(nc, &cm);

    mg_coap_free_options(&cm);

    // error check
    if (res == 0) {

      UARTprintf("Sent CON with msg_id = %d\n", cm.msg_id);

    } else {

       UARTprintf("Error: %d\n", res);

    }

    return cm.msg_id;
}
