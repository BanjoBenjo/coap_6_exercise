/*
 * VS Group 6
 * Coap Client, sensor to actor
 *
 * The Client can GET/OBSERVE/PUT/PUSH on the Server.
 * When the Sensor Value have a specific Value the
 * Client controls an Actuator via a specific PUT
 * message.
 *
 * For the Programm we are using the Moongose Libary.
 * Description https://cesanta.com/docs/overview/intro.html
 *
 * For the 2 Connections Coap Handler are Implemented and they are
 * reacting on specific events.
 *
 * The Different Message Methodes are located in methodsCoAP.c
 *
 * the connection with the network is implemented via LWIP udp
 *
 *  Leon Fixl
 *  Benjamin Wagner
 *  Thomas Schweizer
 */

#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>


// Mongoose   library
#include "mongoose/mongoose.h"

#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "driverlib/flash.h"
#include "driverlib/interrupt.h"
#include "driverlib/gpio.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/systick.h"
#include "driverlib/timer.h"


// utils libraries
#include "utils/lwiplib.h"
#include "utils/ustdlib.h"
#include "utils/uartstdio.h"

//drivers library
#include "drivers/pinout.h"
#include "drivers/buttons.h"

// userLib libraries
#include "userLib/delay.h"
#include "userLib/uartConfig.h"
#include "userLib/io.h"
#include "userLib/timerInit.h"
#include "userLib/methodsCoAP.h"
#include "main.h"


// Mongoose COAP relevant parameter
uint16_t msg_id =0;
static int s_time_to_exit = 0;

// Address server
static char *s_default_address = "udp://192.168.178.183:5683";

// Mongoose connection manager
struct mg_mgr mgr;
struct mg_connection *nc;

// System clock frequency
uint32_t  g_ui32SysClock;

// IP address variables
uint32_t g_ui32IPAddress;

// check if IP is set
static volatile bool g_IPAddressSet = false;

//check connection
static volatile bool connect = false;
//*****************************************************************************
//
// Necessary Mongoose functions
//
//*****************************************************************************
int gettimeofday(struct timeval *tv, void *tzvp){
    tv->tv_sec = time(NULL);
    tv->tv_usec = 0;
    return 0;
}
void mg_lwip_mgr_schedule_poll(struct mg_mgr *mgr){
}
//*****************************************************************************
//
// Required by lwIP library to support any host-related timer functions.
// This function is called in "lwIPServiceTimers()" from the "lwiplib.c" utility
// "lwIPServiceTimers()" is called in "lwIPEthernetIntHandler()" from the "lwiplib.c" utility
// "lwIPEthernetIntHandler()" is registered in the interrupt vector table (in file "..._startup_ccs.c")
//
//*****************************************************************************
void lwIPHostTimerHandler(void){
    static uint32_t ui32OldIPAddress = IP_LINK_DOWN;
    // Get current IP address
    g_ui32IPAddress = lwIPLocalIPAddrGet();
    // Check if IP address has changed
    if (g_ui32IPAddress != ui32OldIPAddress) {
        switch (g_ui32IPAddress) {
            // Indicate there is no link
            case IP_LINK_DOWN: {
                UARTprintf("Link down.\r\n");
                LEDWrite(CLP_D2, 0);
                g_IPAddressSet = false;
                break;
            }

            // No IP address DHCP is running
            case IP_LINK_UP: {
                UARTprintf("Link up.\r\n");
                LEDWrite(CLP_D2, 0);
                g_IPAddressSet = false;
                break;
            }

            default: {
                UARTprintf("IP address: %s\r\n", ipaddr_ntoa((const ip_addr_t *) &g_ui32IPAddress));
                LEDWrite(CLP_D2, CLP_D2);
                g_IPAddressSet = true;
                break;
            }
        }
        // Safe IP address
        ui32OldIPAddress = g_ui32IPAddress;
        io_display_IP(g_ui32IPAddress);
    }
}
//*****************************************************************************
//
// The interrupt handler for the SysTick interrupt.
//
//*****************************************************************************
void SysTickIntHandler(void){

    // Call the lwIP timer handler.
    lwIPTimer(SYSTICKMS);
}
//*****************************************************************************
//
// Interrupt handler for timer 0A
//
//*****************************************************************************
void TimerA0IntHandler(void){
    // clears Interrupt flag of timer0
    TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
}

//*****************************************************************************
//
// Mongoose coap handler for the Sensor
//
//*****************************************************************************
static void coap_handler(struct mg_connection *nc, int ev, void *p){

    switch (ev){
        // CONNECTION with Server successfull
        case MG_EV_CONNECT:{
            UARTprintf("=======================================\n");
            UARTprintf("Successfully connected to Server\n");
            connect = true;
            break;
        }
        // a message has benn sent
        case MG_EV_SEND:{
            UARTprintf("=======================================\n");
            UARTprintf("A message has been send\n");
            break;
        }
        // ACKNOWLEDGMENT recieved
        case MG_EV_COAP_ACK:{
            UARTprintf("=======================================\n");

            // init Payload, length and the message struct
            char *Payload;
            int length=0;
            struct mg_coap_message *cm;

            // reserve Memory for Payload
            Payload = (char *) malloc(200*sizeof(char));

            // get the message send by server
            cm = (struct mg_coap_message *) p;
            length = cm->payload.len;

            UARTprintf("ACKNOWLEDGMENT for message with msg_id = %d received\n", cm->msg_id);

            // if the payload is not empty which means a piggy backed message has been recieved
            if(length >= 1)
            {
                // now get the payload an print it to the console
                strcpy(Payload,cm->payload.p);
                Payload[length]='\0';               // add EOS to payload for string processing
                UARTprintf("Payload= %s\n",Payload);
                printf("Output: %s \n",Payload);
                //delay_ms(500);
            }

            // set time_to_exit to leave while loop in main and
            s_time_to_exit = 1;
            // free storage for payload to avoid memory leak
            free(Payload);
            break;
        }

        // RESET recieved
        case MG_EV_COAP_RST:{
          UARTprintf("=======================================\n");
          struct mg_coap_message *cm = (struct mg_coap_message *) p;
          UARTprintf("RESET for message with msg_id = %d received\n", cm->msg_id);
          s_time_to_exit = 1;
          break;
        }

        // Connection is closed
        case MG_EV_CLOSE: {
            UARTprintf("=======================================\n");
            UARTprintf("COAP Connection closed\n");
            s_time_to_exit = 1;
            connect = false;

//          if (s_time_to_exit == 0)
//          {
//            UARTprintf("Close\n");
//            s_time_to_exit = 1;
//            connect = false;
//          }
          break;
        }
    }
}

//*****************************************************************************
//
//                      Coap Client
//
//*****************************************************************************

int main(void) {
    //*****************************************************************************
    //               System Initialization
    //*****************************************************************************

    uint32_t u0, u1;
    uint8_t mac[6];
    // Make sure the main oscillator is enabled because this is required by
    // the PHY.  The system must have a 25MHz crystal attached to the OSC
    // pins. The SYSCTL_MOSC_HIGHFREQ parameter is used when the crystal
    // frequency is 10MHz or higher.
    SysCtlMOSCConfigSet(SYSCTL_MOSC_HIGHFREQ);
    // Run from the PLL at 120 MHz.
    g_ui32SysClock = MAP_SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ |
                   SYSCTL_OSC_MAIN | SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480),
                   120000000);

    // Configure the device pins.
    PinoutSet(true, false);

    // Configure UART.
    uartConfig_init();

    //Initialize Display
    io_init();

    // Configure board's LEDs: D2 is on when IP has been acquired,
    // D1 is toggled on every HTTP request.
    MAP_GPIOPinTypeGPIOOutput(CLP_D1_PORT, CLP_D1_PIN);
    MAP_GPIOPinTypeGPIOOutput(CLP_D2_PORT, CLP_D2_PIN);
    LEDWrite(CLP_D1, 0);
    LEDWrite(CLP_D2, 0);

    // Configure the hardware MAC address for Ethernet Controller filtering of
    // incoming packets.  The MAC address will be stored in the non-volatile
    // USER0 and USER1 registers.
    MAP_FlashUserGet(&u0, &u1);
    if((u0 == 0xffffffff) || (1 == 0xffffffff))
    {
       // Let the user know there is no MAC address
       UARTprintf("No MAC programmed!\n");
       while(1){
       }
    }

    // Convert the 24/24 split MAC address from NV ram into a 32/16 split
    // MAC address needed to program the hardware registers, then program
    // the MAC address into the Ethernet Controller registers.
    mac[0] = ((u0 >> 0) & 0xff);
    mac[1] = ((u0 >> 8) & 0xff);
    mac[2] = ((u0 >> 16) & 0xff);
    mac[3] = ((u1 >> 0) & 0xff);
    mac[4] = ((u1 >> 8) & 0xff);
    mac[5] = ((u1 >> 16) & 0xff);

    // Initialize the lwIP library, using DHCP.
    lwIPInit(g_ui32SysClock, mac, 0, 0, 0, IPADDR_USE_DHCP);
    MAP_SysTickPeriodSet(g_ui32SysClock / SYSTICKHZ);
    MAP_SysTickEnable();
    MAP_SysTickIntEnable();

    while(!g_IPAddressSet){
        // Wait for DHCP process to finish
    }

    // Init of mongoose manager, connection and setting protocol to COAP
    mg_mgr_init(&mgr, 0);
    nc = mg_connect(&mgr, s_default_address, coap_handler);
    mg_set_protocol_coap(nc);

    // wait for first connection
    while(!connect)
    {
        mg_mgr_poll(&mgr, 2);
    }


    //*****************************************************************************
    //          Main Procedure
    //*****************************************************************************

    // call Discovery method to see what resources are on the server
    msg_id = DISCOVERY_Met(nc, mgr, msg_id);
    // poll till a response has been recieved
    while (!s_time_to_exit)
    {
        mg_mgr_poll(&mgr, 2);

    }
    s_time_to_exit = 0;

    char payload[10];
    bool Exit = false;
    int action = 0;

    while(!Exit)
    {
        printf("Resource \"/basic\" is hard selected in the code \n");
        printf("Please choose an action and Input given NUMBER \n");
        printf("1:GET | 2:PUT | 3:Exit");
        scanf("%d", &action);
        fflush(stdin);

        if(action == 1)
        {
            // GET method called
            msg_id = GET_Met(nc, mgr, msg_id);

            // poll till response received
            while (!s_time_to_exit)
            {
                mg_mgr_poll(&mgr, 2);
            }
            s_time_to_exit=0;
        }

        if(action == 2)
        {
            // HERE GOES YOUR CODE FOR CALLING PUT METHOD
            printf("Enter Payload (max 10 chars) for PUT:\n");
            scanf("%s", &payload);

            msg_id = PUT_Met(nc, mgr, msg_id, payload);

            while (!s_time_to_exit)
            {
               mg_mgr_poll(&mgr, 2);
            }
           s_time_to_exit=0;
        }

        if(action == 3)
        {
            Exit = true;
        }

    }

    // endless loop
    while(true){}
}
