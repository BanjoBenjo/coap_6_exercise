/*
 * methodsCoap.h
 *
 *  Created on: 25.06.2020
 *      Author: Tomas Schweizer
 *              Leon Fixl
 *              Benjamin Wagner
 */

#ifndef USERLIB_METHODSCOAP_H_
#define USERLIB_METHODSCOAP_H_

//*****************************************************************************
//
// COAP option defines
//
//*****************************************************************************
#define COAP_URI_PATH_BASIC                     "basic"
#define COAP_CONTENT_FORMAT_PLAIN_TEXT          "\0"
#define COAP_CONTENT_FORMAT_LINK_FORMAT         "("
#define COAP_URI_PATH_DISCOVERY                 ".well-known/core"


//*****************************************************************************
//
// COAP method defines
//
//*****************************************************************************
#define MG_COAP_MSG_EMPTY           0x00
#define MG_COAP_MSG_GET             0x01
#define MG_COAP_MSG_POST            0x02
#define MG_COAP_MSG_PUT             0x03
#define MG_COAP_MSG_DELETE          0x04

//*****************************************************************************
//
// COAP method prototypes
//
//*****************************************************************************
uint16_t DISCOVERY_Met(struct mg_connection *nc ,struct mg_mgr mgr, uint16_t l_ui16MessageID);
uint16_t PUT_Met(struct mg_connection *nc, struct mg_mgr mgr, uint16_t l_ui16MessageID, char payload[]);
uint16_t GET_Met(struct mg_connection *nc,struct mg_mgr mgr, uint16_t l_ui16MessageID);
//*****************************************************************************
//
// COAP helper function prototypes
//
//*****************************************************************************
uint16_t generateMessageID(uint16_t l_ui16MessageID);

#endif /* USERLIB_METHODSCOAP_H_ */
