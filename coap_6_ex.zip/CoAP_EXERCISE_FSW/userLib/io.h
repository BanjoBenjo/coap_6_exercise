//*****************************************************************************
//
// io.h - Prototypes for I/O routines
//
//*****************************************************************************

#ifndef __IO_H__
#define __IO_H__

#ifdef __cplusplus
extern "C"
{
#endif

/** @brief Select booster pack position (1 or 2)    */
#define BOOSTER_PACK_POSITION   2

//*****************************************************************************
//
// Exported function prototypes.
//
//*****************************************************************************

/** @brief Initialize IOs (ports, display, etc.)
*/
void io_init(void);


/** @brief Print local IP to display
* @param  localIP    : local IP address
*/
void io_display_IP(uint32_t localIP);

void io_display_COAP();



#ifdef __cplusplus
}
#endif

#endif // __IO_H__
