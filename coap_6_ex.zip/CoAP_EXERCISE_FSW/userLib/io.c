//*****************************************************************************
//
// io.c - I/O routines
//
//*****************************************************************************
#include <CFAF128128B0145T/CFAF128128B0145T.h>      // Display
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_pwm.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"      // allows the use of the MAP_ prefix
#include "drivers/pinout.h"

#include "io.h"


// The system clock speed.
extern uint32_t g_ui32SysClock;





//*****************************************************************************
//
// Initialize IO
//
//*****************************************************************************
void io_init(void)
{



    // Display
    // *******
    // Init Display module
    CFAF128128B0145T_init(BOOSTER_PACK_POSITION, g_ui32SysClock, 20000000);
    CFAF128128B0145T_clear(CFAF128128B0145T_color_black);


    return;
}



void io_display_IP(uint32_t localIP)
{
    char    localStr[22];
    int     l;


    // Titel                      123456789012345678901
    CFAF128128B0145T_text(0, 10, "     Coap Client     ", CFAF128128B0145T_color_white, CFAF128128B0145T_color_black, 1, 1);
    CFAF128128B0145T_text(0, 20, "_____________________", CFAF128128B0145T_color_white, CFAF128128B0145T_color_black, 1, 1);


    // IP info
    sprintf(&localStr[0]," %d.%d.%d.%d", localIP & 0xff, (localIP >> 8) & 0xff, (localIP >> 16) & 0xff, (localIP >> 24) & 0xff);
    l = strlen(&localStr[0]);
    memset(&localStr[l], ' ', 21-l);    // fill with SPACEs
    localStr[21] = '\0';                // terminate string

    switch(localIP){
        case 0xFFFFFFFF:
            //                            123456789012345678901
            CFAF128128B0145T_text(0, 30, "Waiting for LINK ... ", CFAF128128B0145T_color_white, CFAF128128B0145T_color_black, 1, 1);
            break;

        case 0:
            //                            123456789012345678901
            CFAF128128B0145T_text(0, 30, "Waiting for IP ...   ", CFAF128128B0145T_color_white, CFAF128128B0145T_color_black, 1, 1);
            break;

        default:
            //                            123456789012345678901
            CFAF128128B0145T_text(0, 30, "IP-Address:        ", CFAF128128B0145T_color_white, CFAF128128B0145T_color_black, 1, 1);
            CFAF128128B0145T_text(0, 40, localStr, CFAF128128B0145T_color_white, CFAF128128B0145T_color_black, 1, 1);
            break;


    }


    return;
}

void io_display_COAP(int event){

    // clear display
    CFAF128128B0145T_clear(CFAF128128B0145T_color_black);

    // Titel                      123456789012345678901
    CFAF128128B0145T_text(0, 10, "     Coap Client     ", CFAF128128B0145T_color_white, CFAF128128B0145T_color_black, 1, 1);
    CFAF128128B0145T_text(0, 20, "_____________________", CFAF128128B0145T_color_white, CFAF128128B0145T_color_black, 1, 1);

    switch(event){

    case 0:
        //                            123456789012345678901
        CFAF128128B0145T_text(0, 30, "coap send", CFAF128128B0145T_color_white, CFAF128128B0145T_color_black, 1, 1);


    }



}





